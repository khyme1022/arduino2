package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import android.app.DatePickerDialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TabHost;
import android.widget.TextView;
import android.widget.Toast;

import com.github.mikephil.charting.animation.Easing;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.Description;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class MainActivity extends AppCompatActivity implements TabHost.OnTabChangeListener, View.OnClickListener {
    LineChart lineChart;
    EditText editText;
    Button button;
    TabHost tabHost1;
    TextView textView;
    long now = System.currentTimeMillis();
    Date CurrentDate = new Date(now);
    SimpleDateFormat sdfNow = new SimpleDateFormat("yyyy-MM-dd");
    String formatDate = sdfNow.format(CurrentDate);
    public static final String NOTIFICATION_CHANNEL_ID = "10001";
    long Time = System.nanoTime();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("알람인데");
        tabHost1 = (TabHost) findViewById(R.id.tabHost1) ;
        tabHost1.setup() ;
        TabHost.TabSpec ts1 = tabHost1.newTabSpec("DUST") ;
        ts1.setContent(R.id.content1) ;
        ts1.setIndicator("먼지") ;
        tabHost1.addTab(ts1)  ;

        TabHost.TabSpec ts2 = tabHost1.newTabSpec("MQ2") ;
        ts2.setContent(R.id.content1) ;
        ts2.setIndicator("가스") ;
        tabHost1.addTab(ts2) ;

        TabHost.TabSpec ts3 = tabHost1.newTabSpec("MQ5") ;
        ts3.setContent(R.id.content1) ;
        ts3.setIndicator("유해가스") ;
        tabHost1.addTab(ts3) ;

        TabHost.TabSpec ts4 = tabHost1.newTabSpec("MQ6") ;
        ts4.setContent(R.id.content1) ;
        ts4.setIndicator("LPG") ;
        tabHost1.addTab(ts4) ;

        TabHost.TabSpec ts5 = tabHost1.newTabSpec("MQ8") ;
        ts5.setContent(R.id.content1) ;
        ts5.setIndicator("수소") ;
        tabHost1.addTab(ts5) ;

        TabHost.TabSpec ts6 = tabHost1.newTabSpec("MQ9") ;
        ts6.setContent(R.id.content1) ;
        ts6.setIndicator("일산화탄소") ;
        tabHost1.addTab(ts6) ;

        tabHost1.setCurrentTab(1);
        tabHost1.setOnTabChangedListener(this);

        lineChart = (LineChart)findViewById(R.id.chart);
        button = (Button)findViewById(R.id.button);
        button.setOnClickListener(this);

        editText = (EditText)findViewById(R.id.EDate2);
        editText.setText(formatDate);

        Button calB1 = (Button)findViewById(R.id.calb1);
        calB1.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                SearchDate("EDate");
            }
        });
        Button calB2 = (Button)findViewById(R.id.calb2);
        calB2.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                SearchDate("EDate2");
            }
        });
        loopTime();
    }
    public void NotificationSomethings(float avg, String idid){
        NotificationManager notificationManager = (NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
        Intent notificationIntent = new Intent(this, ResultActivity.class);
        notificationIntent.putExtra("notificationId", avg); //전달할 값
        notificationIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK) ;
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, notificationIntent,  PendingIntent.FLAG_UPDATE_CURRENT);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID)
                .setLargeIcon(BitmapFactory.decodeResource(getResources(), R.drawable.ic_launcher_foreground)) //BitMap 이미지 요구
                .setContentTitle(idid+ "의 수치가 너무 높아요")
                .setContentText(avg+" 이정도면 환기를 좀...")
// 더 많은 내용이라서 일부만 보여줘야 하는 경우 아래 주석을 제거하면 setContentText에 있는 문자열 대신 아래 문자열을 보여줌
                //.setStyle(new NotificationCompat.BigTextStyle().bigText("더 많은 내용을 보여줘야 하는 경우..."))
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setContentIntent(pendingIntent) // 사용자가 노티피케이션을 탭시 ResultActivity로 이동하도록 설정
                .setAutoCancel(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {

            builder.setSmallIcon(R.drawable.ic_launcher_foreground); //mipmap 사용시 Oreo 이상에서 시스템 UI 에러남
            CharSequence channelName  = "노티페케이션 채널";
            String description = "오레오 이상을 위한 것임";
            int importance = NotificationManager.IMPORTANCE_HIGH;

            NotificationChannel channel = new NotificationChannel(NOTIFICATION_CHANNEL_ID, channelName , importance);
            channel.setDescription(description);

            // 노티피케이션 채널을 시스템에 등록
            assert notificationManager != null;
            notificationManager.createNotificationChannel(channel);

        }else builder.setSmallIcon(R.mipmap.ic_launcher); // Oreo 이하에서 mipmap 사용하지 않으면 Couldn't create icon: StatusBarIcon 에러남

        assert notificationManager != null;
        notificationManager.notify(1234, builder.build()); // 고유숫자로 노티피케이션 동작시킴
    }
    public void changeData(){
        try {
            String result;
            String idid = tabHost1.getCurrentTabTag();
            RegisterActivity task = new RegisterActivity();
            editText = (EditText)findViewById(R.id.EDate);
            EditText editText1 = (EditText)findViewById(R.id.EDate2);
            String date = editText.getText().toString();
            String date2 = editText1.getText().toString();
            result = task.execute(idid,date,date2).get();
            String[] result2 = result.split(" ");
            List<Entry> entries = new ArrayList<>();
            float sum=0;
            if(idid.equals("DUST")){
                for(int i=result2.length-10;i<result2.length;i++){
                    entries.add(new Entry(i,Float.parseFloat(result2[i])));
                    sum+=Float.parseFloat(result2[i]);
                }
            }else{
                for(int i=result2.length-10;i<result2.length;i++){
                    entries.add(new Entry(i,Integer.parseInt(result2[i])));
                    sum+=Integer.parseInt(result2[i]);
                }
            }
            float avg = sum/10;
            System.out.println(avg);
            if(avg>300){
                System.out.println("dsadsads");
                NotificationSomethings(avg,idid);
            }
            textView= (TextView)findViewById(R.id.Average2);
            textView.setText(String.valueOf(sum/(10)));
            makeChart(entries,idid);
        } catch (Exception e) {
            Log.i("DBtest", ".....ERROR.....!");
        }
    }
    public void allchangeData(){
        try {
            String result;
            String idid = tabHost1.getCurrentTabTag();
            RegisterActivity task = new RegisterActivity();
            editText = (EditText)findViewById(R.id.EDate);
            EditText editText1 = (EditText)findViewById(R.id.EDate2);
            String date = editText.getText().toString();
            String date2 = editText1.getText().toString();
            result = task.execute(idid,date,date2).get();
            String[] result2 = result.split(" ");
            List<Entry> entries = new ArrayList<>();
            float sum=0;
            if(idid.equals("DUST")){
                for(int i=result2.length-10;i<result2.length;i++){
                    entries.add(new Entry(i,Float.parseFloat(result2[i])));
                    sum+=Float.parseFloat(result2[i]);
                }
            }else{
                for(int i=result2.length-10;i<result2.length;i++){
                    entries.add(new Entry(i,Integer.parseInt(result2[i])));
                    sum+=Integer.parseInt(result2[i]);
                }
            }
            float avg = sum/10;
            System.out.println(avg);
            if(avg>300){
                System.out.println("dsadsads");
                NotificationSomethings(avg,idid);
            }
            textView= (TextView)findViewById(R.id.Average2);
            textView.setText(String.valueOf(sum/(10)));
            makeChart(entries,idid);
        } catch (Exception e) {
            Log.i("DBtest", ".....ERROR.....!");
        }
    }
    @Override
    public void onTabChanged(String tabId){
        changeData();
    }
    @Override
    public void onClick(View v) {
        changeData();
    }
    public void SearchDate(String name)
    {
        Calendar c= Calendar.getInstance();
        int nYear =  c.get(Calendar.YEAR);
        int nMon = c.get(Calendar.MONTH);
        int nDay = c.get(Calendar.DAY_OF_MONTH);
        if(name.equals("EDate")) {
            editText = (EditText) findViewById(R.id.EDate);
        }else{
            editText = (EditText) findViewById(R.id.EDate2);
        }
        DatePickerDialog.OnDateSetListener mDataSetListener= new DatePickerDialog.OnDateSetListener(){
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                String strDate  = String.valueOf(year)+"-";
                strDate+=String.valueOf(monthOfYear+1)+"-";
                if(dayOfMonth>10) {
                    strDate += String.valueOf(dayOfMonth);
                }else{
                    strDate += "0"+String.valueOf(dayOfMonth);
                }
                Toast.makeText(getApplicationContext(),strDate,Toast.LENGTH_SHORT).show();
                editText.setText(strDate);
            }
        };
        DatePickerDialog oDialog = new DatePickerDialog(this,android.R.style.Theme_DeviceDefault_Light_Dialog,mDataSetListener,nYear,nMon,nDay);
        oDialog.show();
    }
    public void makeChart(List<Entry> entries, String idid){
        LineDataSet lineDataSet = new LineDataSet(entries,idid);
        lineDataSet.setLineWidth(2);
        lineDataSet.setCircleRadius(6);
        lineDataSet.setCircleColor(Color.parseColor("#FFA1B4DC"));
        lineDataSet.setCircleColorHole(Color.BLUE);
        lineDataSet.setColor(Color.parseColor("#FFA1B4DC"));
        lineDataSet.setDrawCircleHole(true);
        lineDataSet.setDrawCircles(true);
        lineDataSet.setDrawHorizontalHighlightIndicator(false);
        lineDataSet.setDrawHighlightIndicators(false);
        lineDataSet.setDrawValues(false);

        LineData lineData = new LineData(lineDataSet);
        lineChart.setData(lineData);

        XAxis xAxis = lineChart.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setTextColor(Color.BLACK);
        xAxis.enableGridDashedLine(8, 24, 0);

        YAxis yLAxis = lineChart.getAxisLeft();
        yLAxis.setTextColor(Color.BLACK);

        YAxis yRAxis = lineChart.getAxisRight();
        yRAxis.setDrawLabels(false);
        yRAxis.setDrawAxisLine(false);
        yRAxis.setDrawGridLines(false);

        Description description = new Description();
        description.setText("");

        lineChart.setDoubleTapToZoomEnabled(false);
        lineChart.setDrawGridBackground(false);
        lineChart.setDescription(description);
        lineChart.animateY(2000, Easing.EasingOption.EaseInCubic);
        lineChart.invalidate();
    }
    public void loopTime(){
        final Handler handler = new Handler(){
            @Override
            public  void handleMessage(Message msg){
            }
        };
        Runnable task = new Runnable() {
            @Override
            public void run() {
                while(true){
                    try{
                        allchangeData();
                        Thread.sleep(10000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                        handler.sendEmptyMessage(1);
                    }
                }
            }
        };
        Thread thread = new Thread(task);
        thread.start();
    }
}
